﻿Public Class Form1

    Private Sub OPERARToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OPERARToolStripMenuItem.Click

        Dim nit_ As String = TextBox1.Text
        Dim nombre_ As String = TextBox2.Text
        Dim personas_ As String = TextBox3.Text
        Dim cabina_ As String = ""
        Dim clase_ As String = ""

        If RadioButton_sencilla.Checked Then
            cabina_ = "sencilla"
        ElseIf RadioButton_doble.Checked Then
            cabina_ = "doble"
        Else
            cabina_ = "compartida"
        End If

        If RadioButton_primera.Checked Then
            clase_ = "primera"
        Else
            clase_ = "segunda"
        End If

        operar(nit_, nombre_, cabina_, personas_, clase_)
        MsgBox("La reserva se ha operado exitosamente.")

    End Sub

    Private Sub MOSTRARToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MOSTRARToolStripMenuItem.Click

        DataGridView1.Rows.Clear()
        For i As Integer = 0 To index - 1
            Dim reserva = {nitt(i), cabina(i), personass(i), "Q " + precio_i(i).ToString(), "Q " + precio_t(i).ToString()}
            DataGridView1.Rows.Add(reserva)
        Next

    End Sub

    Private Sub CONSULTARToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CONSULTARToolStripMenuItem.Click

        Dim nit_input As String = InputBox("Ingresa el numero de NIT con el que se realizó la reservación:", "Buscar Reservación", 0)
        For i As Integer = 0 To index - 1
            If nitt(i) = nit_input Then

                MsgBox("Reserva encontrada.")
                TextBox1.Text = nitt(i)
                TextBox2.Text = nombre(i)
                TextBox3.Text = personass(i)

                If cabina(i) = "sencilla" Then
                    RadioButton_sencilla.Checked = True
                ElseIf cabina(i) = "doble" Then
                    RadioButton_doble.Checked = True
                Else
                    RadioButton_compartida.Checked = True
                End If

                If clase(i) = "primera" Then
                    RadioButton_primera.Checked = True
                Else
                    RadioButton_segunda.Checked = True
                End If

                DataGridView1.Rows.Clear()
                Dim reserva = {nitt(i), cabina(i), personass(i), "Q " + precio_i(i).ToString(), "Q " + precio_t(i).ToString()}
                DataGridView1.Rows.Add(reserva)

            End If
        Next
        MsgBox("No se ha encontrado ninguna reserva con el NIT ingresado.")

    End Sub

    Private Sub ORDENDESCENDENTEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ORDENDESCENDENTEToolStripMenuItem.Click

    End Sub

    Private Sub VECTORESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VECTORESToolStripMenuItem.Click

        For i As Integer = 0 To index - 1
            nitt(i) = Nothing
            nombre(i) = Nothing
            cabina(i) = Nothing
            clase(i) = Nothing
            personass(i) = Nothing
            precio_i(i) = Nothing
            precio_t(i) = Nothing
        Next

        index = 0
        DataGridView1.Rows.Clear()
        MsgBox("Vectores limpiados exitosamente.")

    End Sub

    Private Sub DATOSDEENTRADAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DATOSDEENTRADAToolStripMenuItem.Click

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        RadioButton_sencilla.Checked = False
        RadioButton_doble.Checked = False
        RadioButton_compartida.Checked = False
        RadioButton_primera.Checked = False
        RadioButton_segunda.Checked = False
        MsgBox("Datos de entrada limpiados exitosamente.")

    End Sub
End Class
