﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_sencilla = New System.Windows.Forms.RadioButton()
        Me.RadioButton_doble = New System.Windows.Forms.RadioButton()
        Me.RadioButton_compartida = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_segunda = New System.Windows.Forms.RadioButton()
        Me.RadioButton_primera = New System.Windows.Forms.RadioButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OPERARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MOSTRARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSULTARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ORDENDESCENDENTEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LIMPIARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SALIRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VECTORESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DATOSDEENTRADAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.NIT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TIPO_CABINA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PERSONAS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRECIO_INDIVIDUAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRECIO_TOTAL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "NIT:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(93, 36)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(204, 20)
        Me.TextBox1.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(93, 68)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(204, 20)
        Me.TextBox2.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "NOMBRE:"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(93, 101)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(204, 20)
        Me.TextBox3.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "PERSONAS:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton_compartida)
        Me.GroupBox1.Controls.Add(Me.RadioButton_doble)
        Me.GroupBox1.Controls.Add(Me.RadioButton_sencilla)
        Me.GroupBox1.Location = New System.Drawing.Point(319, 36)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(114, 93)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TIPO CABINA:"
        '
        'RadioButton_sencilla
        '
        Me.RadioButton_sencilla.AutoSize = True
        Me.RadioButton_sencilla.Location = New System.Drawing.Point(15, 19)
        Me.RadioButton_sencilla.Name = "RadioButton_sencilla"
        Me.RadioButton_sencilla.Size = New System.Drawing.Size(62, 17)
        Me.RadioButton_sencilla.TabIndex = 7
        Me.RadioButton_sencilla.TabStop = True
        Me.RadioButton_sencilla.Text = "Sencilla"
        Me.RadioButton_sencilla.UseVisualStyleBackColor = True
        '
        'RadioButton_doble
        '
        Me.RadioButton_doble.AutoSize = True
        Me.RadioButton_doble.Location = New System.Drawing.Point(15, 42)
        Me.RadioButton_doble.Name = "RadioButton_doble"
        Me.RadioButton_doble.Size = New System.Drawing.Size(53, 17)
        Me.RadioButton_doble.TabIndex = 8
        Me.RadioButton_doble.TabStop = True
        Me.RadioButton_doble.Text = "Doble"
        Me.RadioButton_doble.UseVisualStyleBackColor = True
        '
        'RadioButton_compartida
        '
        Me.RadioButton_compartida.AutoSize = True
        Me.RadioButton_compartida.Location = New System.Drawing.Point(15, 65)
        Me.RadioButton_compartida.Name = "RadioButton_compartida"
        Me.RadioButton_compartida.Size = New System.Drawing.Size(78, 17)
        Me.RadioButton_compartida.TabIndex = 9
        Me.RadioButton_compartida.TabStop = True
        Me.RadioButton_compartida.Text = "Compartida"
        Me.RadioButton_compartida.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton_segunda)
        Me.GroupBox2.Controls.Add(Me.RadioButton_primera)
        Me.GroupBox2.Location = New System.Drawing.Point(457, 36)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(106, 93)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "TIPO CLASE:"
        '
        'RadioButton_segunda
        '
        Me.RadioButton_segunda.AutoSize = True
        Me.RadioButton_segunda.Location = New System.Drawing.Point(16, 51)
        Me.RadioButton_segunda.Name = "RadioButton_segunda"
        Me.RadioButton_segunda.Size = New System.Drawing.Size(68, 17)
        Me.RadioButton_segunda.TabIndex = 8
        Me.RadioButton_segunda.TabStop = True
        Me.RadioButton_segunda.Text = "Segunda"
        Me.RadioButton_segunda.UseVisualStyleBackColor = True
        '
        'RadioButton_primera
        '
        Me.RadioButton_primera.AutoSize = True
        Me.RadioButton_primera.Location = New System.Drawing.Point(16, 28)
        Me.RadioButton_primera.Name = "RadioButton_primera"
        Me.RadioButton_primera.Size = New System.Drawing.Size(60, 17)
        Me.RadioButton_primera.TabIndex = 7
        Me.RadioButton_primera.TabStop = True
        Me.RadioButton_primera.Text = "Primera"
        Me.RadioButton_primera.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OPERARToolStripMenuItem, Me.MOSTRARToolStripMenuItem, Me.CONSULTARToolStripMenuItem, Me.ORDENDESCENDENTEToolStripMenuItem, Me.LIMPIARToolStripMenuItem, Me.SALIRToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(584, 24)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OPERARToolStripMenuItem
        '
        Me.OPERARToolStripMenuItem.Name = "OPERARToolStripMenuItem"
        Me.OPERARToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.OPERARToolStripMenuItem.Text = "OPERAR"
        '
        'MOSTRARToolStripMenuItem
        '
        Me.MOSTRARToolStripMenuItem.Name = "MOSTRARToolStripMenuItem"
        Me.MOSTRARToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.MOSTRARToolStripMenuItem.Text = "MOSTRAR"
        '
        'CONSULTARToolStripMenuItem
        '
        Me.CONSULTARToolStripMenuItem.Name = "CONSULTARToolStripMenuItem"
        Me.CONSULTARToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.CONSULTARToolStripMenuItem.Text = "CONSULTAR"
        '
        'ORDENDESCENDENTEToolStripMenuItem
        '
        Me.ORDENDESCENDENTEToolStripMenuItem.Name = "ORDENDESCENDENTEToolStripMenuItem"
        Me.ORDENDESCENDENTEToolStripMenuItem.Size = New System.Drawing.Size(139, 20)
        Me.ORDENDESCENDENTEToolStripMenuItem.Text = "ORDEN DESCENDENTE"
        '
        'LIMPIARToolStripMenuItem
        '
        Me.LIMPIARToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VECTORESToolStripMenuItem, Me.DATOSDEENTRADAToolStripMenuItem})
        Me.LIMPIARToolStripMenuItem.Name = "LIMPIARToolStripMenuItem"
        Me.LIMPIARToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.LIMPIARToolStripMenuItem.Text = "LIMPIAR"
        '
        'SALIRToolStripMenuItem
        '
        Me.SALIRToolStripMenuItem.Name = "SALIRToolStripMenuItem"
        Me.SALIRToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.SALIRToolStripMenuItem.Text = "SALIR"
        '
        'VECTORESToolStripMenuItem
        '
        Me.VECTORESToolStripMenuItem.Name = "VECTORESToolStripMenuItem"
        Me.VECTORESToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.VECTORESToolStripMenuItem.Text = "VECTORES"
        '
        'DATOSDEENTRADAToolStripMenuItem
        '
        Me.DATOSDEENTRADAToolStripMenuItem.Name = "DATOSDEENTRADAToolStripMenuItem"
        Me.DATOSDEENTRADAToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DATOSDEENTRADAToolStripMenuItem.Text = "DATOS DE ENTRADA"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NIT, Me.TIPO_CABINA, Me.PERSONAS, Me.PRECIO_INDIVIDUAL, Me.PRECIO_TOTAL})
        Me.DataGridView1.Location = New System.Drawing.Point(21, 147)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(542, 261)
        Me.DataGridView1.TabIndex = 12
        '
        'NIT
        '
        Me.NIT.HeaderText = "NIT"
        Me.NIT.Name = "NIT"
        '
        'TIPO_CABINA
        '
        Me.TIPO_CABINA.HeaderText = "TIPO CABINA"
        Me.TIPO_CABINA.Name = "TIPO_CABINA"
        '
        'PERSONAS
        '
        Me.PERSONAS.HeaderText = "NUMERO PERSONAS"
        Me.PERSONAS.Name = "PERSONAS"
        '
        'PRECIO_INDIVIDUAL
        '
        Me.PRECIO_INDIVIDUAL.HeaderText = "PRECIO INDIVIDUAL"
        Me.PRECIO_INDIVIDUAL.Name = "PRECIO_INDIVIDUAL"
        '
        'PRECIO_TOTAL
        '
        Me.PRECIO_TOTAL.HeaderText = "PRECIO TOTAL"
        Me.PRECIO_TOTAL.Name = "PRECIO_TOTAL"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 425)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "201700620_CRUCERO"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton_compartida As RadioButton
    Friend WithEvents RadioButton_doble As RadioButton
    Friend WithEvents RadioButton_sencilla As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RadioButton_segunda As RadioButton
    Friend WithEvents RadioButton_primera As RadioButton
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents OPERARToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MOSTRARToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CONSULTARToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ORDENDESCENDENTEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LIMPIARToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VECTORESToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DATOSDEENTRADAToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SALIRToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents NIT As DataGridViewTextBoxColumn
    Friend WithEvents TIPO_CABINA As DataGridViewTextBoxColumn
    Friend WithEvents PERSONAS As DataGridViewTextBoxColumn
    Friend WithEvents PRECIO_INDIVIDUAL As DataGridViewTextBoxColumn
    Friend WithEvents PRECIO_TOTAL As DataGridViewTextBoxColumn
End Class
