﻿Module Module1

    Public nitt(6) As String
    Public nombre(6) As String
    Public cabina(6) As String
    Public clase(6) As String
    Public personass(6) As String
    Public precio_i(6) As Double
    Public precio_t(6) As Double
    Public index As Integer = 0

    Sub operar(nit_ As String, nombre_ As String, cabina_ As String, personas_ As String, clase_ As String)

        Dim costo_i = 0.0
        Dim costo_t = Integer.Parse(personas_)

        If cabina_ = "sencilla" Then
            If clase_ = "primera" Then
                costo_i = 400.0
            Else
                costo_i = 375.0
            End If
        ElseIf cabina_ = "doble" Then
            If clase_ = "primera" Then
                costo_i = 700.0
            Else
                costo_i = 600.0
            End If
        Else
            If clase_ = "primera" Then
                costo_i = 350.0
            Else
                costo_i = 300.0
            End If
        End If

        costo_t = costo_i * costo_t

        If index > 5 Then
            MsgBox("vectores llenos")
            Return
        End If

        nitt(index) = nit_
        nombre(index) = nombre_
        cabina(index) = cabina_
        clase(index) = clase_
        personass(index) = personas_
        precio_i(index) = costo_i
        precio_t(index) = costo_t
        index = index + 1

    End Sub

End Module
